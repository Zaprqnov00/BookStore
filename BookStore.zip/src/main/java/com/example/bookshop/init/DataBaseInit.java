package com.example.bookshop.init;

import com.example.bookshop.service.AuthorService;
import com.example.bookshop.service.GenreService;
import com.example.bookshop.service.PublisherService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataBaseInit implements CommandLineRunner {

    private final PublisherService publisherService;
    private final GenreService genreService;
    private final AuthorService authorService;

    public DataBaseInit(PublisherService publisherService, GenreService genreService, AuthorService authorService) {
        this.publisherService = publisherService;
        this.genreService = genreService;
        this.authorService = authorService;
    }

    @Override
    public void run(String... args) throws Exception {
        this.publisherService.initPublishDataBase();
        this.genreService.initGenresDataBase();
        this.authorService.initAuthorDataBase();
    }
}
