package com.example.bookshop.model.binding;

import com.example.bookshop.model.entity.enums.*;
import com.example.bookshop.util.ExceptionMessage;
import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AddBookBindingModel {

    @Size(min = 5, max = 15, message = ExceptionMessage.NAME_LENGTH)
    @NotNull
    private String name;

    @Min(30)
    @NotNull(message = ExceptionMessage.PAGES_NOT_NULL)
    private Integer pages;

    @NotNull(message = ExceptionMessage.DATE_NOT_NULL)
    @DateTimeFormat(pattern = ExceptionMessage.PATTERN)
    @PastOrPresent(message = ExceptionMessage.DATE_PAST_PRESENT_EXC)
    private LocalDate date;

    @NotNull(message = ExceptionMessage.COVERS_NOT_NULL)
    private Covers covers;

    @Positive(message = ExceptionMessage.PRICE_MUST_POSITIVE)
    @NotNull(message = ExceptionMessage.PRICE_NOT_NULL)
    private BigDecimal price;

    @NotNull(message = ExceptionMessage.LANGUAGE_NOT_NULL)
    private Language language;

    @Size(min = 5, message = ExceptionMessage.DESCRIPTION_LENGTH)
    @NotNull
    private String description;

    @Size(min = 5, max = 15, message = ExceptionMessage.EDITOR_NAME_LENGTH)
    @NotNull
    private String editorName;

    @NotNull(message = ExceptionMessage.PUBLISHER_NOT_NULL)
    private PublisherName publisherName;

    @NotNull(message = ExceptionMessage.GENRE_NAME_NOT_NULL)
    private GenreName genre;

    @NotNull(message = ExceptionMessage.AUTHOR_NAME_NOT_NULL)
    private AuthorName authorName;

    public AddBookBindingModel() {
    }

    public GenreName getGenre() {
        return genre;
    }

    public AuthorName getAuthorName() {
        return authorName;
    }

    public void setAuthorName(AuthorName authorName) {
        this.authorName = authorName;
    }

    public void setGenre(GenreName genre) {
        this.genre = genre;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Covers getCovers() {
        return covers;
    }

    public void setCovers(Covers covers) {
        this.covers = covers;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEditorName() {
        return editorName;
    }

    public void setEditorName(String editorName) {
        this.editorName = editorName;
    }

    public PublisherName getPublisherName() {
        return publisherName;
    }

    public void setPublisherName(PublisherName publisherName) {
        this.publisherName = publisherName;
    }
}
