package com.example.bookshop.model.dto;

import com.example.bookshop.model.entity.Author;
import com.example.bookshop.model.entity.Publisher;
import com.example.bookshop.model.entity.enums.Covers;
import com.example.bookshop.model.entity.enums.GenreName;
import com.example.bookshop.model.entity.enums.Language;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

public class BookServiceDTO {

    private String id;

    @NotNull
    private String name;

    @NotNull
    private Integer pages;

    @NotNull
    private LocalDate date;

    @NotNull
    private Covers covers;

    @NotNull
    private BigDecimal price;

    @NotNull
    private Language language;

    @NotNull
    private String description;

    @NotNull
    private String editorName;

    @NotNull
    private Publisher publisher;

    @NotNull
    private GenreName genre;

    @NotNull
    private Author author;


    public BookServiceDTO() {
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public GenreName getGenre() {
        return genre;
    }

    public void setGenre(GenreName genre) {
        this.genre = genre;
    }

    public Publisher getPublisher() {
        return publisher;
    }

    public void setPublisher(Publisher publisher) {
        this.publisher = publisher;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Covers getCovers() {
        return covers;
    }

    public void setCovers(Covers covers) {
        this.covers = covers;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEditorName() {
        return editorName;
    }

    public void setEditorName(String editorName) {
        this.editorName = editorName;
    }
}
