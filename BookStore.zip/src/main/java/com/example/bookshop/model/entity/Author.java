package com.example.bookshop.model.entity;

import com.example.bookshop.model.entity.enums.AuthorName;
import com.example.bookshop.model.entity.enums.Gender;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "authors")
public class Author extends BaseEntity{

    @Enumerated(EnumType.STRING)
    private AuthorName authorName;

    @Enumerated(EnumType.STRING)
    @NotNull
    private Gender gender;

    @Column(nullable = false)
    private LocalDate born;

    @Column(nullable = false)
    private LocalDate died;

    @Column(nullable = false)
    private String nationality;

    @Column(nullable = false)
    private String education;

    @OneToMany(targetEntity = Book.class, mappedBy = "author")
    private List<Book> books;

    public Author() {
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public AuthorName getAuthorName() {
        return authorName;
    }

    public void setAuthorName(AuthorName authorName) {
        this.authorName = authorName;
    }

    public LocalDate getBorn() {
        return born;
    }

    public void setBorn(LocalDate born) {
        this.born = born;
    }

    public LocalDate getDied() {
        return died;
    }

    public void setDied(LocalDate died) {
        this.died = died;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
