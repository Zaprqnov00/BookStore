package com.example.bookshop.model.entity;

import com.example.bookshop.model.entity.enums.GenreName;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.util.List;

@Entity
@Table(name = "genres")
public class Genre extends BaseEntity{

    @Enumerated(EnumType.STRING)
    @NotNull
    private GenreName name;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @OneToMany(targetEntity = Book.class, mappedBy = "genre")
    private List<Book> books;

    public Genre() {
    }

    public GenreName getName() {
        return name;
    }

    public void setName(GenreName name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
