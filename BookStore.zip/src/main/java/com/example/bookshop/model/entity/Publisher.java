package com.example.bookshop.model.entity;

import com.example.bookshop.model.entity.enums.PublisherName;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.util.List;

@Entity
@Table(name = "publishers")
public class Publisher extends BaseEntity{

    @Enumerated(EnumType.STRING)
    @NotNull
    private PublisherName name;

    @Column(nullable = false)
    private String address;

    @Column(nullable = false)
    private String city;

    @OneToMany(targetEntity = Book.class, mappedBy = "publisher")
    private List<Book> books;

    public Publisher() {
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public PublisherName getName() {
        return name;
    }

    public void setName(PublisherName name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
