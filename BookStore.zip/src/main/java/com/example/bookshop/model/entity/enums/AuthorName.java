package com.example.bookshop.model.entity.enums;

public enum AuthorName {
    StephenKing,
    NicolaMendelsohn,
    TomEgeland,
    SarahJMaas,
    HarperLee,
    ZahariKarabashliev,
    JoshMalerman,
    MarioPuzo,
}
