package com.example.bookshop.model.entity.enums;

public enum Covers {
    Solid,
    Soft
}
