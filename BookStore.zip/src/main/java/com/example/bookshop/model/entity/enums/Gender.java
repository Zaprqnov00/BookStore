package com.example.bookshop.model.entity.enums;

public enum Gender {
    Male,
    Female
}
