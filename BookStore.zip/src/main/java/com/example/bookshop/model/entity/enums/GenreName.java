package com.example.bookshop.model.entity.enums;

public enum GenreName {
    Fantasy,
    Adventure,
    Romance,
    Contemporary,
    Dystopian,
    Mystery,
    Horror,
    Thriller,
    Paranormal,
    HistoricalFiction,
    ScienceFiction,
    Children,
    Memoir,
    Cookbook,
    Art,
    Development,
    MotivationalHealth,
    History,
    Travel,
    Humor
}
