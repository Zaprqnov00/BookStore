package com.example.bookshop.model.entity.enums;

public enum Language {
    English,
    Spanish,
    Bulgaria,
    Italy,
    Polish,
    Russia,
    Scotland,
    Irish,
    Greek,
    Turkey,
    Indonesia

}
