package com.example.bookshop.model.entity.enums;

public enum PublisherName {
    Ciela,
    Helikon,
    Egmont,
    IztokZapad,
    Ibis,
    Bard,
    Enthusiast,
    DejaBook,
    Fama,
    Gnezdoto,
    Kibea
}
