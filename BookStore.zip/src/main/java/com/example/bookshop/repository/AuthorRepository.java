package com.example.bookshop.repository;

import com.example.bookshop.model.entity.Author;
import com.example.bookshop.model.entity.enums.AuthorName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AuthorRepository extends JpaRepository<Author, String> {

    Optional<Author> findByAuthorName(AuthorName authorName);
}
