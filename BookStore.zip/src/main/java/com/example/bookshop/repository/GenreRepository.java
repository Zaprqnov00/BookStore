package com.example.bookshop.repository;

import com.example.bookshop.model.entity.Genre;
import com.example.bookshop.model.entity.enums.GenreName;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GenreRepository extends JpaRepository<Genre, String> {

    Optional<Genre> findByName(@NotNull GenreName name);
}
