package com.example.bookshop.repository;

import com.example.bookshop.model.entity.Publisher;
import com.example.bookshop.model.entity.enums.PublisherName;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PublisherRepository extends JpaRepository<Publisher, String> {

    Optional<Publisher> findByName(PublisherName name);
}
