package com.example.bookshop.service;

import com.example.bookshop.model.entity.Author;
import com.example.bookshop.model.entity.enums.AuthorName;

public interface AuthorService {

    void initAuthorDataBase();

    Author findByName(AuthorName authorName);
}
