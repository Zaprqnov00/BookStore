package com.example.bookshop.service;

import com.example.bookshop.model.dto.BookServiceDTO;
import com.example.bookshop.model.entity.Book;

import java.util.List;

public interface BookService {
    void addBook(BookServiceDTO bookServiceDTO);

    void deleteBookById(String id);

    List<Book> findAllBooksByUserId(String id);
}
