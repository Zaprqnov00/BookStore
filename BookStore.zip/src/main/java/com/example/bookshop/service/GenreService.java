package com.example.bookshop.service;

import com.example.bookshop.model.entity.Genre;
import com.example.bookshop.model.entity.enums.GenreName;

public interface GenreService {
    void initGenresDataBase();

    Genre findByName(GenreName genre);
}
