package com.example.bookshop.service;

import com.example.bookshop.model.entity.Publisher;
import com.example.bookshop.model.entity.enums.PublisherName;

public interface PublisherService {

    void initPublishDataBase();

    Publisher findByName(PublisherName name);
}
