package com.example.bookshop.service;

import com.example.bookshop.model.dto.UserServiceDTO;
import com.example.bookshop.model.entity.User;

public interface UserService {
    void register(UserServiceDTO userServiceDTO);

    UserServiceDTO findByUsernameAndPassword(String username, String password);

    void login(String id, String username);

    void logout(String id, String username);

    User findById(String id);
}
