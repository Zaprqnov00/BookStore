package com.example.bookshop.service.impl;

import com.example.bookshop.model.entity.Author;
import com.example.bookshop.model.entity.enums.AuthorName;
import com.example.bookshop.model.entity.enums.Gender;
import com.example.bookshop.repository.AuthorRepository;
import com.example.bookshop.service.AuthorService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Month;

@Service
public class AuthorServiceImpl implements AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorServiceImpl(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @Override
    public void initAuthorDataBase() {

        if (this.authorRepository.count() == 0){

            for (AuthorName currentAuthorName :AuthorName.values()) {
                Author author = new Author();
                author.setAuthorName(currentAuthorName);

                initAuthorsInformationInDataBase(currentAuthorName, author);

                this.authorRepository.save(author);
            }
        }
    }

    @Override
    public Author findByName(AuthorName authorName) {

        return this.authorRepository
                .findByAuthorName(authorName)
                .orElse(null);
    }

    private static void initAuthorsInformationInDataBase(AuthorName currentAuthorName, Author author) {
        switch (currentAuthorName){
            case HarperLee:
                author.setEducation("University of Alabama");
                author.setGender(Gender.Male);
                author.setNationality("American");
                author.setBorn(LocalDate.of(1926, Month.APRIL, 28));
                author.setDied(LocalDate.of(2016, Month.FEBRUARY, 16));
                break;

            case StephenKing:
                author.setEducation("University of Maine");
                author.setGender(Gender.Male);
                author.setNationality("American");
                author.setBorn(LocalDate.of(1947, Month.SEPTEMBER, 21));
                author.setDied(LocalDate.of(1987, Month.JULY, 30));
                break;

            case NicolaMendelsohn:
                author.setEducation("B.A. English and Theatre Studies, University of Leeds");
                author.setGender(Gender.Female);
                author.setNationality("American");
                author.setBorn(LocalDate.of(1971, Month.AUGUST, 29));
                author.setDied(LocalDate.of(2001, Month.DECEMBER, 15));
                break;
            case TomEgeland:
                author.setEducation("Manchester High School for Girls");
                author.setGender(Gender.Male);
                author.setNationality("Norwegian");
                author.setBorn(LocalDate.of(1959, Month.JULY, 8));
                author.setDied(LocalDate.of(2008, Month.AUGUST, 30));
                break;
            case SarahJMaas:
                author.setEducation("University of Leeds, Manchester High School for Girls");
                author.setGender(Gender.Female);
                author.setNationality("American");
                author.setBorn(LocalDate.of(1986, Month.MARCH, 5));
                author.setDied(LocalDate.of(2012, Month.JULY, 1));
                break;
            case ZahariKarabashliev:
                author.setEducation("Shumen University");
                author.setGender(Gender.Male);
                author.setNationality("Bulgarian");
                author.setBorn(LocalDate.of(1968, Month.APRIL, 14));
                author.setDied(LocalDate.of(1996, Month.JULY, 2));
                break;
            case JoshMalerman:
                author.setEducation("USA University");
                author.setGender(Gender.Male);
                author.setNationality("American");
                author.setBorn(LocalDate.of(1954, Month.OCTOBER, 10));
                author.setDied(LocalDate.of(2000, Month.JULY, 12));
                break;
            case MarioPuzo:
                author.setEducation("USA University");
                author.setGender(Gender.Male);
                author.setNationality("American");
                author.setBorn(LocalDate.of(1920, Month.OCTOBER, 15));
                author.setDied(LocalDate.of(1999, Month.JULY, 2));
                break;
        }
    }
}
