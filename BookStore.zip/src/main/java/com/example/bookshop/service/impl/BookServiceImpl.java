package com.example.bookshop.service.impl;

import com.example.bookshop.model.dto.BookServiceDTO;
import com.example.bookshop.model.entity.Book;
import com.example.bookshop.repository.BookRepository;
import com.example.bookshop.sec.CurrentBook;
import com.example.bookshop.sec.CurrentUser;
import com.example.bookshop.service.*;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookServiceImpl implements BookService {

    private final ModelMapper modelMapper;
    private final BookRepository bookRepository;
    private final CurrentUser currentUser;
    private final UserService userService;
    private final PublisherService publisherService;
    private final AuthorService authorService;
    private final GenreService genreService;
    private final CurrentBook currentBook;
    public BookServiceImpl(ModelMapper modelMapper, BookRepository bookRepository, CurrentUser currentUser, UserService userService, PublisherService publisherService, AuthorService authorService, GenreService genreService, CurrentBook currentBook) {
        this.modelMapper = modelMapper;
        this.bookRepository = bookRepository;
        this.currentUser = currentUser;
        this.userService = userService;
        this.publisherService = publisherService;
        this.authorService = authorService;
        this.genreService = genreService;
        this.currentBook = currentBook;
    }

    @Override
    public void addBook(BookServiceDTO bookServiceDTO) {
        Book book = modelMapper.map(bookServiceDTO, Book.class);
        book.setUser(this.userService.findById(this.currentUser.getId()));
        book.setPublisher(this.publisherService.findByName(bookServiceDTO.getPublisher().getName()));
        book.setAuthor(this.authorService.findByName(bookServiceDTO.getAuthor().getAuthorName()));
        book.setGenre(this.genreService.findByName(bookServiceDTO.getGenre()));

        setInformationInCurrentBook(bookServiceDTO);

        this.bookRepository.save(book);
    }


    @Override
    public void deleteBookById(String id) {

        this.bookRepository.deleteById(id);
    }

    @Override
    public List<Book> findAllBooksByUserId(String id) {

        return this.bookRepository.findByUserId(id);

    }

    private void setInformationInCurrentBook(BookServiceDTO bookServiceDTO) {
        this.currentBook.setName(bookServiceDTO.getName());
        this.currentBook.setLanguage(bookServiceDTO.getLanguage().name());
        this.currentBook.setPages(bookServiceDTO.getPages());
        this.currentBook.setPrice(bookServiceDTO.getPrice());
    }
}
