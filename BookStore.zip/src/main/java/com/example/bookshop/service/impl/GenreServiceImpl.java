package com.example.bookshop.service.impl;

import com.example.bookshop.model.entity.Genre;
import com.example.bookshop.model.entity.enums.GenreName;
import com.example.bookshop.repository.GenreRepository;
import com.example.bookshop.service.GenreService;
import com.example.bookshop.util.GenreDescriptionMessage;
import org.springframework.stereotype.Service;

@Service
public class GenreServiceImpl implements GenreService {

    private final GenreRepository genreRepository;

    public GenreServiceImpl(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }

    @Override
    public void initGenresDataBase() {

        if (this.genreRepository.count() == 0){
            for (GenreName currentGenreName :GenreName.values()) {

                Genre genre = new Genre();
                genre.setName(currentGenreName);

                initGenreInformationDataBase(currentGenreName, genre);

                this.genreRepository.save(genre);
            }
        }
    }

    @Override
    public Genre findByName(GenreName genre) {

        return this.genreRepository
                .findByName(genre)
                .orElse(null);
    }

    private static void initGenreInformationDataBase(GenreName currentGenreName, Genre genre) {
        switch (currentGenreName){
            case History:
                genre.setDescription(GenreDescriptionMessage.HISTORY);
                break;
            case Fantasy:
                genre.setDescription(GenreDescriptionMessage.FANTASY);
                break;
            case Art:
                genre.setDescription(GenreDescriptionMessage.ART);
                break;
            case Humor:
                genre.setDescription(GenreDescriptionMessage.HUMOR);
                break;
            case Horror:
                genre.setDescription(GenreDescriptionMessage.HORROR);
                break;
            case Memoir:
                genre.setDescription(GenreDescriptionMessage.MEMOIR);
                break;
            case Travel:
                genre.setDescription(GenreDescriptionMessage.TRAVEL);
                break;
            case Mystery:
                genre.setDescription(GenreDescriptionMessage.MYSTERY);
                break;
            case Romance:
                genre.setDescription(GenreDescriptionMessage.ROMANCE);
                break;
            case Children:
                genre.setDescription(GenreDescriptionMessage.CHILDREN);
                break;
            case Cookbook:
                genre.setDescription(GenreDescriptionMessage.COOKBOOK);
                break;
            case Thriller:
                genre.setDescription(GenreDescriptionMessage.THRILLER);
                break;
            case Adventure:
                genre.setDescription(GenreDescriptionMessage.ADVENTURE);
                break;
            case Dystopian:
                genre.setDescription(GenreDescriptionMessage.DYSTOPIAN);
                break;
            case Paranormal:
                genre.setDescription(GenreDescriptionMessage.PARANORMAL);
                break;
            case Development:
                genre.setDescription(GenreDescriptionMessage.DEVELOPMENT);
                break;
            case Contemporary:
                genre.setDescription(GenreDescriptionMessage.CONTEMPORARY);
                break;
            case ScienceFiction:
                genre.setDescription(GenreDescriptionMessage.SINCE_FICTION);
                break;
            case HistoricalFiction:
                genre.setDescription(GenreDescriptionMessage.HISTORICAL_FICTION);
                break;
            case MotivationalHealth:
                genre.setDescription(GenreDescriptionMessage.MOTIVATIONAL_HEALTH);
                break;
        }
    }
}
