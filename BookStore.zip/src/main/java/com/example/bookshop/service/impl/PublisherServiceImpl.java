package com.example.bookshop.service.impl;

import com.example.bookshop.model.entity.Publisher;
import com.example.bookshop.model.entity.enums.PublisherName;
import com.example.bookshop.repository.PublisherRepository;
import com.example.bookshop.service.PublisherService;
import org.springframework.stereotype.Service;

@Service
public class PublisherServiceImpl implements PublisherService {

    private final PublisherRepository publisherRepository;

    public PublisherServiceImpl(PublisherRepository publisherRepository) {
        this.publisherRepository = publisherRepository;
    }

    @Override
    public void initPublishDataBase() {

        if (this.publisherRepository.count() == 0) {
            for (PublisherName currentName : PublisherName.values()) {

                Publisher publisher = new Publisher();
                publisher.setName(currentName);

                initPublisherInformation(currentName, publisher);

                this.publisherRepository.save(publisher);
            }
        }
    }

    @Override
    public Publisher findByName(PublisherName name) {

        return this.publisherRepository.findByName(name).orElse(null);
    }

    private static void initPublisherInformation(PublisherName currentName, Publisher publisher) {
        switch (currentName) {
            case Bard:
                publisher.setCity("Sofia");
                publisher.setAddress("str. 'Ivan Vazov 15'");
                break;
            case Ciela:
                publisher.setCity("Sofia");
                publisher.setAddress("str. 'Darvin 165'");
                break;
            case Helikon:
                publisher.setCity("Varna");
                publisher.setAddress("str. 'Galilei Galileo 2'");
                break;
            case Egmont:
                publisher.setCity("Sofia");
                publisher.setAddress("str. 'Karmena 102'");
                break;
            case IztokZapad:
                publisher.setCity("Burgas");
                publisher.setAddress("str. 'Kremos 32'");
                break;
            case Ibis:
                publisher.setCity("Plovdiv");
                publisher.setAddress("str. 'Bogomil 22'");
                break;
            case Enthusiast:
                publisher.setCity("Stara Zagora");
                publisher.setAddress("str. '3 mart'");
                break;
            case DejaBook:
                publisher.setCity("Sofia");
                publisher.setAddress("str. Kiril Bogorod 115'");
                break;
            case Fama:
                publisher.setCity("Plovdiv");
                publisher.setAddress("str. 'Chernishevski 7'");
                break;
            case Gnezdoto:
                publisher.setCity("Sofia");
                publisher.setAddress("str. 'Mariq Luiza'");
                break;
            case Kibea:
                publisher.setCity("Sozopol");
                publisher.setAddress("str. 'Sopotiqn 6'");
                break;
        }
    }
}
