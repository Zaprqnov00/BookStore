package com.example.bookshop.service.impl;

import com.example.bookshop.model.dto.UserServiceDTO;
import com.example.bookshop.model.entity.User;
import com.example.bookshop.repository.UserRepository;
import com.example.bookshop.sec.CurrentUser;
import com.example.bookshop.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final CurrentUser currentUser;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(ModelMapper modelMapper, UserRepository userRepository, CurrentUser currentUser, PasswordEncoder passwordEncoder) {
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.currentUser = currentUser;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void register(UserServiceDTO userServiceDTO) {
        User user = modelMapper.map(userServiceDTO, User.class);

        //user.setPassword(passwordEncoder.encode(user.getPassword()));

        this.userRepository.save(user);
    }

    @Override
    public UserServiceDTO findByUsernameAndPassword(String username, String password) {

        return this.userRepository.
                findByUsernameAndPassword(username, password)
                .map(user -> modelMapper.map(user, UserServiceDTO.class))
                .orElse(null);
    }

    @Override
    public void login(String id, String username) {
        this.currentUser.setId(id);
        this.currentUser.setUsername(username);
    }

    @Override
    public void logout(String id, String username) {
        this.currentUser.setId(null);
        this.currentUser.setUsername(null);
    }

    @Override
    public User findById(String id) {

        return this.userRepository
                .findById(id)
                .orElse(null);
    }


}
