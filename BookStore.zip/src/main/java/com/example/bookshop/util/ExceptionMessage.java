package com.example.bookshop.util;

public enum ExceptionMessage {
    ;
    public final static String NAME_LENGTH = "Name length must be between 5 and 15 characters!";
    public final static String USERNAME_LENGTH = "Username length must be between 3 and 10 characters!";
    public final static String PASSWORD_LENGTH = "Password length must be between 3 and 12 characters!";
    public final static String PAGES_NOT_NULL = "Pages cannot be null!";
    public final static String DATE_NOT_NULL = "Date cannot be empty!";
    public final static String DATE_PAST_PRESENT_EXC = "Cannot buy a book in future!";
    public final static String PATTERN = "yyyy-MM-dd";
    public final static String COVERS_NOT_NULL = "Please select covers!";
    public final static String PRICE_NOT_NULL = "Price cannot be null!";
    public final static String PRICE_MUST_POSITIVE = "Price must be positive number!";
    public final static String LANGUAGE_NOT_NULL = "Language cannot be null!";
    public final static String DESCRIPTION_LENGTH = "Description length more than 5 characters!";
    public final static String EDITOR_NAME_LENGTH = "Editor name length must be between 5 and 15 characters!";
    public final static String PUBLISHER_NOT_NULL = "Publisher name cannot be null!";
    public final static String GENRE_NAME_NOT_NULL = "Genre name cannot be null!";
    public final static String AUTHOR_NAME_NOT_NULL = "Author name cannot be null!";
    public final static String FIRST_NAME_LENGTH = "First name length must be between 3 and 10!";
    public final static String LAST_NAME_LENGTH = "Last name length must be between 3 and 10!";
    public final static String EMAIL_VALID = "Enter valid email!";
    public final static String EMAIL_NOT_NULL = "Email cannot be null!";
}
