package com.example.bookshop.web;

import com.example.bookshop.model.binding.AddBookBindingModel;
import com.example.bookshop.model.dto.BookServiceDTO;
import com.example.bookshop.sec.CurrentUser;
import com.example.bookshop.service.BookService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/books")
public class BookController {

    private final ModelMapper modelMapper;
    private final BookService bookService;
    private final CurrentUser currentUser;

    public BookController(ModelMapper modelMapper, BookService bookService, CurrentUser currentUser) {
        this.modelMapper = modelMapper;
        this.bookService = bookService;
        this.currentUser = currentUser;
    }

    @ModelAttribute
    public AddBookBindingModel addBookBindingModel(){
        return new AddBookBindingModel();
    }

    @GetMapping("/history")
    public String booksHistory(){
        return "books-history";
    }

    @GetMapping("/add")
    public String addBooksPage(){
        return "books-add";
    }

    @GetMapping("/view")
    public String viewAllBooks(Model model){

        model.addAttribute("books", this.bookService.findAllBooksByUserId(this.currentUser.getId()));

        return "books-view";
    }

    @GetMapping("/successfully")
    public String successfullyAddBook(){
        return "successfully-add-book";
    }

    @PostMapping("/add")
    public String addBooks(@Valid AddBookBindingModel addBookBindingModel,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes){

        if (bindingResult.hasErrors()){
            redirectAttributes.addFlashAttribute("addBookBindingModel", addBookBindingModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.addBookBindingModel",
                    bindingResult);

            return "redirect:/books/add";
        }

        BookServiceDTO bookServiceDTO = modelMapper.map(addBookBindingModel, BookServiceDTO.class);

        this.bookService.addBook(bookServiceDTO);

        return "redirect:/books/successfully";
    }

    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable String id){

        this.bookService.deleteBookById(id);

        return "redirect:/books/view";
    }
}
