package com.example.bookshop.web;

import com.example.bookshop.sec.CurrentUser;
import com.example.bookshop.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final CurrentUser currentUser;
    private final BookService bookService;

    public HomeController(CurrentUser currentUser, BookService bookService) {
        this.currentUser = currentUser;
        this.bookService = bookService;
    }

    @GetMapping("/")
    public String index(Model model){
        if (this.currentUser.getId() == null) {
            return "index";
        }

        return "home";
    }

    @GetMapping("/about")
    public String about(){

        return "about";
    }
}
